"use client"

import type React from "react"

import { useState } from "react"
import { format } from "date-fns"
import { CalendarIcon, Check } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"

// Replace the serviceTypes array with packages
const packages = [
  { id: "1", name: "Basic Package", description: "Standard service", price: "$50" },
  { id: "2", name: "Premium Package", description: "Enhanced service with extras", price: "$100" },
  { id: "3", name: "Deluxe Package", description: "Our most comprehensive service", price: "$200" },
]

export default function BookingForm() {
  const [date, setDate] = useState<Date>()
  const [selectedPackage, setSelectedPackage] = useState<string>("")
  const [step, setStep] = useState(1)

  // Update the formData state to match the database columns
  const [formData, setFormData] = useState({
    user_id: "1", // This would typically come from authentication
    package_id: "",
    booking_date: "",
    status: "pending", // Default status
    total_price: "",
    payment_status: "unpaid", // Default payment status
    special_request: "",
    number_of_people: 1,
    name: "",
    email: "",
    phone: "",
  })

  // Update handleInputChange to handle number inputs
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: name === "number_of_people" ? Number.parseInt(value) || 1 : value,
    }))
  }

  const handleNextStep = () => {
    setStep((prev) => prev + 1)
  }

  const handlePrevStep = () => {
    setStep((prev) => prev - 1)
  }

  // Update the handleSubmit function
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Format the data to match your database schema
    const bookingData = {
      user_id: formData.user_id,
      package_id: selectedPackage,
      booking_date: date ? format(date, "yyyy-MM-dd") : "",
      status: "pending",
      total_price: packages.find((pkg) => pkg.id === selectedPackage)?.price.replace("$", "") || "0",
      payment_status: "unpaid",
      special_request: formData.special_request,
      number_of_people: formData.number_of_people,
    }

    console.log(bookingData)
    // Move to confirmation step
    handleNextStep()
  }

  // Replace selectedServiceDetails with selectedPackageDetails
  const selectedPackageDetails = packages.find((pkg) => pkg.id === selectedPackage)

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Booking Details</CardTitle>
          <div className="flex items-center space-x-2">
            <div
              className={cn(
                "flex items-center justify-center w-8 h-8 rounded-full border",
                step >= 1 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground",
              )}
            >
              1
            </div>
            <Separator className="w-8" />
            <div
              className={cn(
                "flex items-center justify-center w-8 h-8 rounded-full border",
                step >= 2 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground",
              )}
            >
              2
            </div>
            <Separator className="w-8" />
            <div
              className={cn(
                "flex items-center justify-center w-8 h-8 rounded-full border",
                step >= 3 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground",
              )}
            >
              3
            </div>
          </div>
        </div>
        <CardDescription>
          {step === 1 && "Select your preferred package and date"}
          {step === 2 && "Fill in your details"}
          {step === 3 && "Review and confirm your booking"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit}>
          {step === 1 && (
            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="package">Package Type</Label>
                <Select value={selectedPackage} onValueChange={setSelectedPackage}>
                  <SelectTrigger id="package">
                    <SelectValue placeholder="Select a package" />
                  </SelectTrigger>
                  <SelectContent>
                    {packages.map((pkg) => (
                      <SelectItem key={pkg.id} value={pkg.id}>
                        <div className="flex justify-between items-center w-full">
                          <span>{pkg.name}</span>
                          <span className="text-muted-foreground text-sm">{pkg.price}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, "PPP") : "Select a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      initialFocus
                      disabled={(date) => date < new Date()}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="number_of_people">Number of People</Label>
                <Input
                  id="number_of_people"
                  name="number_of_people"
                  type="number"
                  min="1"
                  value={formData.number_of_people}
                  onChange={handleInputChange}
                  placeholder="Enter number of people"
                  className="w-full"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="Enter your full name"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="Enter your email"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  placeholder="Enter your phone number"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="special_request">Special Requests</Label>
                <Textarea
                  id="special_request"
                  name="special_request"
                  value={formData.special_request}
                  onChange={handleInputChange}
                  placeholder="Any special requests or information we should know"
                  rows={3}
                />
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <div className="rounded-lg border p-4">
                <h3 className="font-medium mb-4">Booking Summary</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Package:</span>
                    <span className="font-medium">{selectedPackageDetails?.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Date:</span>
                    <span className="font-medium">{date ? format(date, "PPP") : ""}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Number of People:</span>
                    <span className="font-medium">{formData.number_of_people}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Name:</span>
                    <span className="font-medium">{formData.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Email:</span>
                    <span className="font-medium">{formData.email}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Phone:</span>
                    <span className="font-medium">{formData.phone}</span>
                  </div>
                  {formData.special_request && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Special Request:</span>
                      <span className="font-medium">{formData.special_request}</span>
                    </div>
                  )}
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Status:</span>
                    <span className="font-medium">Pending</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Payment Status:</span>
                    <span className="font-medium">Unpaid</span>
                  </div>
                  <div className="flex justify-between font-semibold">
                    <span>Total Price:</span>
                    <span>{selectedPackageDetails?.price}</span>
                  </div>
                </div>
              </div>
              <div className="rounded-lg bg-green-50 p-4 flex items-center">
                <Check className="h-5 w-5 text-green-500 mr-2" />
                <p className="text-green-700">Your booking is ready to be confirmed!</p>
              </div>
            </div>
          )}
        </form>
      </CardContent>
      <CardFooter className="flex justify-between">
        {step > 1 ? (
          <Button variant="outline" onClick={handlePrevStep}>
            Back
          </Button>
        ) : (
          <div></div>
        )}
        {step < 3 ? (
          <Button
            onClick={handleNextStep}
            disabled={
              (step === 1 && (!date || !selectedPackage)) ||
              (step === 2 && (!formData.number_of_people || !formData.name || !formData.email || !formData.phone))
            }
          >
            Continue
          </Button>
        ) : (
          <Button type="submit">Confirm Booking</Button>
        )}
      </CardFooter>
    </Card>
  )
}
